from BaseCanvas.base_canvas import BaseCanvas

BaseCanvas = BaseCanvas
