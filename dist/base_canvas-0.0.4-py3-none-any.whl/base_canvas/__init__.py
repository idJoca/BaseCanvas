from base_canvas.base_canvas import BaseCanvas

BaseCanvas = BaseCanvas
